package com.example;
import java.util.Scanner;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
public class Main {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        FileWriter writer = new FileWriter("output.txt");
        boolean stop = true; 
        ArrayList<String> list = new ArrayList();
        while(stop) {
            System.out.println("Please input your name.");
            if(scanner.nextLine() == "exit") {
                stop = false;
            }

            
        }
        
    }

    public void assign(String homeowner)  {
        
    }
}