package com.example;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean x = true;
        while (x) {
            String input = scanner.nextLine();
            if(input.equalsIgnoreCase("exit")) {
                x = false;
            } else {
            
            String name = input; 
            String email = input;
            String password = input;
            validation(name, email, password);
        }
    }
    }
    public static void validation(String n, String e, String pswd) {
            StringBuilder nwithdots = new StringBuilder();
            
            String[] parts = n.toString().split(" ");
            nwithdots.append(parts[0] + "." + parts[parts.length - 1]);

            if(pswdcheck(pswd) && emailcheck(e) ) {
                System.out.println("Profile for " + n + " created. \nUsername: " + nwithdots.toString() );
            } else {
                System.out.println("Error: Invalid email or password.");
            }
            
    }
    public static boolean emailcheck(String e) {
            if (e.endsWith("@gmail.com") || e.endsWith("@yahoo.com") ||e.endsWith("@outlook.com") ) {
                return true;
            } else return false;
    }
    public static boolean pswdcheck(String pswd) {
        boolean upper = false, lower = false, digit = false, special = false;
        for (char ch : pswd.toCharArray()) {
            if(Character.isUpperCase(ch)){
		        upper = true;
            } else if (Character.isLowerCase(ch)) {
                lower = true;
            } else if (Character.isDigit(ch)) {
                digit = true;
            } else {
                special = true;
            }
                }
        if(upper && lower && digit && special && pswd.length() > 7) {
            return true;
        } else return false; 
    }
    }
