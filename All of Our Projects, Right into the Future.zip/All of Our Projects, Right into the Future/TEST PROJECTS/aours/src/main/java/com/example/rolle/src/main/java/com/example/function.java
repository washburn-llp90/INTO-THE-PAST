package com.example;

import java.util.function.Function;
public class function {
    Function<Double, Double> f = x ->   (2*x)/(3*Math.pow(x, 2));
    Function<Double, Double> df = x -> 2*(3*Math.pow(x, 2));
    int a;
    int b;
    int c;

    public function(int a, int b, int c){
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public double compute(double x){
        return f.apply(x);
    }

    public double deriveCompute(double x){
        return df.apply(x);
    }

    public boolean equalEnds(int a, int b){
        if(compute(a) == compute(b)){
            return true;
        } else {
            return false;
        }
    }

    public boolean 

}
