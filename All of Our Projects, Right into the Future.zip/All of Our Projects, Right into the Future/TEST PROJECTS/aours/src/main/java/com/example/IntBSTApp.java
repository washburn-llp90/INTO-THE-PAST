package com.example;


import java.util.Scanner;
import java.io.FileReader;
import java.io.FileNotFoundException;

public class IntBSTApp {
    public static void main(String[] args) throws FileNotFoundException{
        IntBST bst = new IntBST();
        Scanner scanner = new Scanner(new FileReader("bst.txt"));

        while (scanner.hasNextLine()){
            bst.insert(Integer.parseInt(scanner.nextLine()));
        }
        scanner. close();
        Scanner input = new Scanner(System.in);
    
        System.out.println("Which number do you want me to search?");
        int x = Integer.parseInt(input.nextLine());
        System.out.println(bst.locator(x));
        

    }
}