package com.example;

public class IntBST {
    protected IntBSTNode root;
    
    public IntBST() {
        root = null;
    }
    
    public void visit(IntBSTNode p) {
        System.out.print(p.key + " ");
    }
    
    public IntBSTNode rootCheck() {
        return root;
    }

    public void insert(int key) {
    root = insertAVL(root, key);
}

private IntBSTNode insertAVL(IntBSTNode node, int key) {
    // 1. Standard BST insertion
    if (node == null)
        return new IntBSTNode(key);

    if (key < node.key)
        node.left = insertAVL(node.left, key);
    else if (key > node.key)
        node.right = insertAVL(node.right, key);
    else
        return node; // no duplicates

    // 2. Get balance factor
    int balance = balance(node);

    // 3. Rebalance (4 cases)

    // Left Left Case
    if (balance > 1 && key < node.left.key)
        return rotateRight(node);

    // Right Right Case
    if (balance < -1 && key > node.right.key)
        return rotateLeft(node);

    // Left Right Case
    if (balance > 1 && key > node.left.key) {
        node.left = rotateLeft(node.left);
        return rotateRight(node);
    }

    // Right Left Case
    if (balance < -1 && key < node.right.key) {
        node.right = rotateRight(node.right);
        return rotateLeft(node);
    }

    // return the (unchanged) node pointer
    return node;
}

    

    public int getHeight(IntBSTNode node){
        if(node == null)
            return 0;
        int leftHeight = getHeight(node.left);
        int rightHeight = getHeight(node.right);
        
        return 1 + Math.max(leftHeight, rightHeight);
    }

    public int balance(IntBSTNode node){
        if (node == null)
            return 0;
        return getHeight(node.left) - getHeight(node.right);
    }

    private IntBSTNode rotateRight(IntBSTNode y) {
    IntBSTNode x = y.left;
    IntBSTNode T2 = x.right;

    // Perform rotation
    x.right = y;
    y.left = T2;

    return x; // new root
}

private IntBSTNode rotateLeft(IntBSTNode x) {
    IntBSTNode y = x.right;
    IntBSTNode T2 = y.left;

    // Perform rotation
    y.left = x;
    x.right = T2;

    return y; // new root
}

public int locator(int key){
    IntBSTNode current = root;
    int count = 0;

    while(current != null){
        count++;
        if (key == current.key){
            return count;
        }else if (key < current.key) {
            current = current.left;  
        } else {
            current = current.right;}
        

    }

    return count;
}

}