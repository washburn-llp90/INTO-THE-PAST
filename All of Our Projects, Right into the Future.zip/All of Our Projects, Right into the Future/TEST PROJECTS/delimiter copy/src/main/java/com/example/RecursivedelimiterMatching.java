package com.example;
import java.io.FileReader;
import java.io.IOException;


public class RecursivedelimiterMatching {

    public boolean delimiterMatch() throws IOException {
        try (FileReader reader = new FileReader("text.txt")) {
            return checkContent(reader, '\0');
        } catch (IOException error) {
            System.out.println("WHERE'S THE FILE???");
            return false;
        }
    }

    private boolean checkContent(FileReader reader, char expectedOpen) throws IOException {
        int charInt;
        while ((charInt = reader.read()) != -1) {
            char ch = (char) charInt;
            if (ch == '(' || ch == '[' || ch == '{') {
                if (!checkContent(reader, ch)) return false;
            } else if (ch == ')' || ch == ']' || ch == '}') {
                return matches(expectedOpen, ch);
            } else if (ch == '/') {
                int cch = reader.read();
                if (cch == '*') {
                    if (!skipComment(reader)) {
                        System.out.println("error");
                        return false;
                    }
                }
            }
        }
        return expectedOpen == '\0';
    }
    
    private boolean matches(char open, char close) {
    return (open == '(' && close == ')') ||
           (open == '[' && close == ']') ||
           (open == '{' && close == '}');
}

private boolean skipComment(FileReader reader) throws IOException {
        int prev = 0, c;
        while ((c = reader.read()) != -1) {
            if (prev == '*' && c == '/') return true;
            prev = c;
        }
        return false;
    }
}

