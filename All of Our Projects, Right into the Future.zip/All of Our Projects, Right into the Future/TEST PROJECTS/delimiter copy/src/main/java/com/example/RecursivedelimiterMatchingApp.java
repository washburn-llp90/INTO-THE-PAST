package com.example;
import java.io.IOException;
public class RecursivedelimiterMatchingApp {
    public static void main(String[] args) {
       delimiterMatching match = new delimiterMatching();
       try{
        if(match.delimiterMatch()){
        System.out.println("SUCCESS!!! BALANCED, AS ALL THINGS SHOULD BE.");
        }else{
        System.out.println("FAILURE!!!!!!");
       }
       } catch (IOException error) {
        System.out.println(error.getMessage());
       }
       
    }
}