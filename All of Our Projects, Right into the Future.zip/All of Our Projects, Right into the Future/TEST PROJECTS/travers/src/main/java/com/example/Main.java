package com.example;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        String filename = "bst.txt";
        BST tree = new BST();
            Scanner scanner = new Scanner(new File("bst.txt"));
            while (scanner.hasNext()) {
                if (scanner.hasNextInt()) {
                    int value = scanner.nextInt();
                    tree.insert(value);
                } else {
                    // Skip non-integer tokens gracefully
                    scanner.next();
                }
            }
    
        printTraversal("Breadth-first traversal: ", tree.breadthFirst());
        printTraversal("Pre-order traversal: ", tree.preOrder());
        printTraversal("In-order traversal: ", tree.inOrder());
        printTraversal("Post-order traversalL ", tree.postOrder());
    }

    private static void printTraversal(String label, List<Integer> order) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < order.size(); i++) {
            if (i > 0) sb.append(' ');
            sb.append(order.get(i));
        }
        System.out.println(label + ": " + sb.toString());
    }
}