package com.example;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

public class BST {
    private BSTNode root;
    public BST() {
        this.root = null;
    }
    public void insert(int key) {
        root = insertRec(root, key);
    }
    private BSTNode insertRec(BSTNode node, int key) {
        if (node == null) {
            return new BSTNode(key);
        }
        if (key < node.key) {
            node.left = insertRec(node.left, key);
        } else if (key > node.key) {
            node.right = insertRec(node.right, key);
        }
        return node;
    }
    public List<Integer> breadthFirst() {
        List<Integer> result = new ArrayList<>();
        if (root == null) return result;

        Queue<BSTNode> queue = new ArrayDeque<>();
        queue.add(root);

        while (!queue.isEmpty()) {
         BSTNode current = queue.remove();
        result.add(current.key);
        if (current.left != null) queue.add(current.left);
         if (current.right != null) queue.add(current.right);
        }

     return result;
    }
    public List<Integer> preOrder() {
     List<Integer> result = new ArrayList<>();
     preOrderRec(root, result);
    return result;
    }
    private void preOrderRec(BSTNode node, List<Integer> out) {
     if (node == null) return;
     out.add(node.key);
    preOrderRec(node.left, out);
     preOrderRec(node.right, out);
    }
    public List<Integer> inOrder() {
     List<Integer> result = new ArrayList<>();
     inOrderRec(root, result);
     return result;
    }
    private void inOrderRec(BSTNode node, List<Integer> out) {
     if (node == null) return;
    inOrderRec(node.left, out);
     out.add(node.key);
    inOrderRec(node.right, out);
    }
    public List<Integer> postOrder() {
        List<Integer> result = new ArrayList<>();
        postOrderRec(root, result);
        return result;
    }
    private void postOrderRec(BSTNode node, List<Integer> out) {
    if (node == null) return;
    postOrderRec(node.left, out);
    postOrderRec(node.right, out);
    out.add(node.key);
    }


    public BSTNode getRoot() {
     return root;
    }
}