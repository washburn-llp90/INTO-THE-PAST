package com.example;

public class BSTNode {
    int key;
    BSTNode left;
    BSTNode right;

    public BSTNode(int key) {
        this.key = key;
        this.left = null;
        this.right = null;
    }

    public BSTNode(int key, BSTNode left, BSTNode right) {
        this.key = key;
        this.left = left;
        this.right = right;
    }
}