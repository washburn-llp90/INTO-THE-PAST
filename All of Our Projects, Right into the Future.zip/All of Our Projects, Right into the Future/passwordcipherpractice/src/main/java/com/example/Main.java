package com.example;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog("Please enter your password. Say CHANGE(caps sensitive) to change the current password");
        if (input.equals("CHANGE")) {
            StringBuilder newpass = new StringBuilder(JOptionPane.showInputDialog("Enter your new password here."));
            int shiftstep = randomizer();
            
            while (true) {
                if (passwordStrength(newpass)) {
                    break;
            } else { newpass = new StringBuilder(JOptionPane.showInputDialog("Your password is less than 8 characters, or lacks a number. \n Enter your new password here."));}
            }
            

            
            for (int i = 0; i < newpass.length(); i++) {
                char letter = newpass.charAt(i);
                char shifted;
                
                if (Character.isLowerCase(letter)) {
                    shifted =(char) ((letter - 'a' + shiftstep) % 26 + 'a');
                } else if (Character.isUpperCase(letter)) {
                    shifted =(char) ((letter - 'A' + shiftstep) % 26 + 'A');
                } else { shifted = letter;}
                
                newpass.setCharAt(i,shifted);
            }
            newpass = salter(newpass);
            newpass.insert(0, shiftstep);
            
            


            JOptionPane.showMessageDialog(null, newpass.toString());
        }

    }

    public static Boolean passwordStrength(StringBuilder test) {
        if (test.length() < 8) {

                return false;
            } else if (!test.toString().matches(".*\\d.*")) {
                return false;
            } else {return true;}
    }

    public static int randomizer() {
       int i = (int) Math.floor(Math.random() * 9) + 1;

        return i;
    }

    public static StringBuilder salter(StringBuilder unsalted) {
        int realcount = 0;
        int i = 0;
        int lengthOrig = unsalted.length();
        StringBuilder salted = new StringBuilder(unsalted);
        while ((int) realcount < lengthOrig) {
            realcount++;
            if (realcount % 4 == 0 && realcount != 0) {
                salted.insert(i + 1, (char) ('a' + (Math.random() * 26)));
                salted.insert(i + 2, (char) ('A' + (Math.random() * 26)));

                i += 2;
            }
        i++;
        }
        return salted;
    }
}