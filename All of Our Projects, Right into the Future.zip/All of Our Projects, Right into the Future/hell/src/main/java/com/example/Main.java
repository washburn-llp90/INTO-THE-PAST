package com.example;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int bestGrade = 0;
        
        System.out.println("Input number of students:");
        int counter = scanner.nextInt();

        int[] student = new int[counter];


        for(int i = 0; i < counter; i++) {
            student[i] = scanner.nextInt();
            if(student[i] > bestGrade) {
                bestGrade = student[i];
             }
        }
        scanner.close();

        for(int j = 0; j < counter; j++){ 
            System.out.println("Best Grade:" + bestGrade);
            if(student[j] > (bestGrade - 10)) {
                System.out.println("Student" + j + "score is " + student[j] + " and grade is A");
            } else if (student[j] > (bestGrade - 20)) {
                System.out.println("Student" + j + "score is " + student[j] + " and grade is B");
            } else if (student[j] > (bestGrade - 30)) {
                System.out.println("Student" + j + "score is " + student[j] + " and grade is C");
            } else if (student[j] > (bestGrade - 40)) {
                System.out.println("Student" + j + "score is " + student[j] + " and grade is D");
            } else {
                System.out.println("Student" + j + "score is " + student[j] + " and grade is F");
            }
        }

    }
}