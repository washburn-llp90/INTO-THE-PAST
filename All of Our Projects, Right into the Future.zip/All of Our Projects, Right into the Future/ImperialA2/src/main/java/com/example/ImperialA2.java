package com.example;
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.ArrayList;


public class ImperialA2 {
    public static void main(String[] args) throws FileNotFoundException {
        //System.out.println("Current Working Directory: " + System.getProperty("user.dir"));
        Scanner scanner = new Scanner(new FileReader("grade.txt"));
        ArrayList<String> passed = new ArrayList<>();
        ArrayList<String> failed = new ArrayList<>();
        
        float avgGrade = 0; int studcount = 0; float highestgradeID = 0;
        String highestStudent = "no one";
        System.out.println(scanner.nextLine());
        while(scanner.hasNext()) {
            studcount++;
            StringBuilder student = new StringBuilder();
            student.append(scanner.nextLine() + " ");
            student.insert(0, scanner.nextLine() + " ");
            float grade = Float.parseFloat(scanner.nextLine());
            avgGrade+= grade;
            gradeComp(student.toString(), grade, passed, failed);
            if(highestgradeID < grade) { 
                highestgradeID = grade;
                highestStudent = student.toString(); }
        }
        printing(passed, failed, highestStudent, avgGrade, studcount);
        
    }
    public static void gradeComp(String stud, float gr, ArrayList<String> pass, ArrayList<String> fail) {
        if (gr > 75) {
                pass.add(stud);
            } else {
                fail.add(stud);}
        }

    public static void printing(ArrayList<String> pass, ArrayList<String> fail, String highstud, float avg, int count) {
        System.out.println("Number of failing students: " + fail.size());
        for(String failing : fail) {
            System.out.println(failing);
        }
        System.out.println("\nNumber of passing students: " + pass.size());
        for(String passed : pass) {
            System.out.println(passed);
        }
        System.out.println("\nStudent with the Highest Grade: " + highstud);
        System.out.println("Average grade: " + ((float) avg/count));
    }
    }
    
