package com.example;


import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int a = 0, sum = 0; int total = 0, modtime = 0; 
        String[] idicheckresult = new String[a];
        boolean exit = true;
        

        for (int j = 0; exit; j++) {
            String overallid = scanner.nextLine();
            int idvalue = scanner.nextInt();
            if(overallid.equalsIgnoreCase("exit")) {
                exit = false;
                for(int k = 0; k < j; k++) {
                    System.out.println(idicheckresult[k]);
                }
                scanner.close();
            }
                    
            for(int i = 1; i < 9; i++) {
                sum = idvalue + i;
                total *= sum;
            }
            modtime = total % 11;

            if (overallid.endsWith(String.valueOf(modtime))) {
                idicheckresult[j] = "VALID";
            } else {
                idicheckresult[j] = "INVALID";
            }
            

            

        }

    }
}