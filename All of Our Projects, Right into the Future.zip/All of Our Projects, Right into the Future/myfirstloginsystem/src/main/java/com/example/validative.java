package com.example;

import java.util.Scanner;

public class validative {

    public static String createCredentials(){
        Scanner scanner = new Scanner(System.in);
        boolean x = true;
        while(x) {
            String name = scanner.nextLine();
            String email = scanner.nextLine();
            String password = scanner.nextLine();
            credValid(name, email, password);
            System.out.println("Profile for " + n + "created. \nUsername: " + nwithdots.toString() );
        }
        }
    
    public static String credValid(String n, String e, String pswd) {
            StringBuilder nwithdots = new StringBuilder();
            nwithdots.append(n.trim());
            nwithdots.append(n.toString().substring(0, n.indexOf(" ")));
            nwithdots.append(".");
            nwithdots.append(n.toString().substring(n.indexOf(" ") , n.length()));
            
            while(pswdcheck(pswd) == true) {
                System.out.println("Error: Invalid email or password.");
            }  
            
            
            
    }

    public static boolean pswdcheck(String pswd) {
        boolean upper = false, lower = false, digit = false, special = false;
        for (char ch : pswd.toCharArray()) {
            if(Character.isUpperCase(ch)){
		    upper = true;
            } else if (Character.isLowerCase(ch)) {
                lower = true;
            } else if (Character.isLowerCase(ch)) {
                lower = true;
            } else {
                special = true;
            }
                }
        if(upper && lower && digit && special && pswd.length() > 7) {
            return true;
        } else { return false; }
    }
    
}