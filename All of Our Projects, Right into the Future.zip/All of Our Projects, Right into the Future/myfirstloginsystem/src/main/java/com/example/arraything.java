package com.example;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.Scanner;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

public class arraything {
    private ArrayList<String> unit;
    private ArrayList<String> pswd;
    private int MAX_CAPACITY = 50;
    
    
     
    
    public arraything() {
        unit = new ArrayList<>();
        pswd = new ArrayList<>();
    }
    public StringBuilder readList() {
        StringBuilder fullist = new StringBuilder();
        try {
            Scanner scanner = new Scanner(new FileReader("text.txt"));
            int lineNumber = 0;
            while(scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] parts = line.split("§");
                unit.add(lineNumber, parts[0]);
                pswd.add(lineNumber, parts[1]);
                lineNumber++;
        }

            scanner.close();
            JOptionPane.showMessageDialog(null, "SIGNA");
    } catch (FileNotFoundException e)  {
        fullist.append("Error! My user list is gone!");
    }
    
    return fullist;  
    }
        



    public int addUnit(String string) {
        boolean x = true;
        while(x) {
            int i = 0;
            if(unit.get(i) == null || i < MAX_CAPACITY) {
            unit.add(i, string);
            return i;
            } else i++;
        } return -1;
    }

    public void removeUnit(int unitnumber) {
        if(unit.get(unitnumber) != null) {
            try {
                unit.set(unitnumber,                                                                                                                                             tion e) {
                JOptionPane.showMessageDialog(null, "unit is empty. cannot delete.", "ERROR!", JOptionPane.ERROR_MESSAGE);
            }

        } else {JOptionPane.showMessageDialog(null, "unit is empty. cannot delete.", "ERROR!", JOptionPane.ERROR_MESSAGE);
;}
    }
    public void saveList()  {

        try {
            FileWriter writer = new FileWriter("text.txt");
            for(String u : unit) {
                writer.write(u + "§");
                for(String p : pswd) {
                    writer.write(p + "\n");
                }
            } 
            writer.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error! My user list is gone!");
            e.printStackTrace();
        }
    }


}
