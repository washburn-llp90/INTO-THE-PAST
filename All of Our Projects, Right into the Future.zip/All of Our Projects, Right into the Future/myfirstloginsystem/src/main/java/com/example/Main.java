package com.example;
import javax.swing.JOptionPane;


public class Main {
    public static void main(String[] args) {

        
        String navigation = JOptionPane.showInputDialog("press 1 for adding an entry. press 2 to view entries.");
        if (navigation.equals("1")) {
            newEntry();
        } else { readList();}
        }


    public static StringBuilder sorter(StringBuilder unsorted1, StringBuilder unsorted2, int length) {
        int realcount = 0;

        StringBuilder sorted = new StringBuilder();
        while ((int) realcount < length) {
                    for(int x = 0; x < length && x < unsorted2.length(); x++) {
                    sorted.append(unsorted1.charAt(realcount));
                    sorted.append(unsorted2.charAt(realcount));
                    realcount++;
                    }
                }
        return sorted;   }
             
    public static void newEntry() {
        StringBuilder string1 = new StringBuilder(JOptionPane.showInputDialog("put your name"));
            StringBuilder string2 = new StringBuilder(JOptionPane.showInputDialog("put your next name that will be combined"));
            int string1length = string1.length();
            StringBuilder result = sorter(string1, string2, string1length);
            arraything listofunits = new arraything();
            
            
            String yn = JOptionPane.showInputDialog(null, result.toString() + "\n Save line to array?");
            switch(yn.toLowerCase()) {
            case "y":
            case "yes": 
                JOptionPane.showMessageDialog(null, "Your new Unit ID is: " + listofunits.addUnit(result.toString()) + " Please remember this.");
                
                break;
            case "n":
            case "no":
                JOptionPane.showMessageDialog(null, "cancelling word....");
                
                break;
    } Main.main(null);
}
}