package com.example;

import java.util.Scanner;
import java.io.IOException;
import java.io.File;

public class ImperialA1 {

    public static void main(String[] args) throws IOException{
        File file = new File("numbers.txt");
        Scanner scanner = new Scanner(file);
        
        int champion = Integer.MIN_VALUE;
        int loser = Integer.MAX_VALUE;
        int totality = 0, esum = 0, osum = 0;
        int ecount = 0, ocount = 0, allcount = 0;

        while(scanner.hasNextLine()) {
            int challenger = Integer.parseInt(scanner.nextLine());
            totality += challenger;
            allcount += 1;

            if (challenger > champion) {
                champion = challenger;
            }

            if (challenger < loser) {
                loser = challenger; 
            }

            switch (challenger % 2) {
                case -1:
                case 1:
                    osum += challenger;
                    ocount += 1;
                    break;
                case 0:
                    esum += challenger;
                    ecount += 1;
                    break;
            }
        }
        scanner.close();
        System.out.println("The smallest number: " + loser +
                           "\nThe largest number: " + champion +
                           "\nThe average number: " + ((float) totality / allcount) +
                           "\nThe even average number: " + ((float) esum / ecount) +
                           "\nThe odd average number: " + ((float) osum / ocount));
    }
}
