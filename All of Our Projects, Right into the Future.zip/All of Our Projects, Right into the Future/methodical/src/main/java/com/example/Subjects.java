package com.example;

public class Subjects {
    String title;
    int unit, grade;

    public  Subjects(String title, int unit) {
        this.title = title;
        this.unit = unit;
        grade = 0;
    }

    public Subjects(String title, int unit, int grade) {
        this.title = title;
        this.unit = unit;
        this.grade = grade;
    }
}   


