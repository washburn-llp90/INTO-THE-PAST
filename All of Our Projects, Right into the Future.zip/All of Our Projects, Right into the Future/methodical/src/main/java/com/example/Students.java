package com.example;
import java.util.ArrayList;

public class Students {
    String name;
    ArrayList<Subjects> Subjects = new ArrayList<Subjects>();
    

    public String toString() {
        return "name: " + name + "\n" +
                "average: " + average();
    }

    public double average() {
        float sum = 0, unit  = 0;
        Subjects s;

        for(int i = 0;i<Subjects.size();i++) {
            s = Subjects.get(i);
            sum += s.grade * s.unit;
            unit += s.unit;
        }

    }
}
