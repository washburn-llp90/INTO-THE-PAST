package com.example;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Main {
    public static void main(String[] args)throws FileNotFoundException {
        Scanner scanner = new Scanner(new File("input.txt"));
        ArrayList<Students> students = new ArrayList<Students>();
        Students stud;
        String tempTitle;
        int temp, tempUnit, tempGrade;

        scanner.nextLine();

        while(scanner.hasNext()) {
            stud = new Students();
            stud.name = scanner.nextLine();
            temp = scanner.nextInt();
            scanner.nextLine();

            for(int i = 0;i<temp;i++) {
                tempTitle = scanner.nextLine();
                tempUnit = scanner.nextInt();
                tempGrade = scanner.nextInt();
                if (scanner.hasNext()) { scanner.hasNext();}

                Subjects subj = new Subjects(tempTitle, tempUnit, tempGrade);
                stud.Subjects.add(subj);


            }

            students.add(stud);
        }
        scanner.close();
        System.out.println("Students");
        for(int i=0; i<students.size(); i++) {
            stud = students.get(i);
            System.out.println(stud.toString());
        }
    }
}